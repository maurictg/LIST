﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LIST.Data;
using Microsoft.EntityFrameworkCore;
using LIST.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LIST_Core.Controllers
{
    public class LoginController : Controller
    {
        private readonly LeerlingContext _context;

        public LoginController(LeerlingContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Login login)
        {
                var data = _context.Logindata
                                   .Where(s => s.Username == login.Username)
                                   .FirstOrDefault();

                if (LIST.Classes.Encryption.HASH.checkPBKDF2(login.Password, data.Password))
                {
                    HttpContext.Session.SetString("Token", data.Token);
                     //Response.Redirect()
                    ViewBag.Message = data.Token;
                    return View("Index");
                }
                else
                {
                    ViewBag.Message = "Gebruikersnaam of wachtwoord onjuist";
                    return View("Index");
                }
            

        }
    }
}