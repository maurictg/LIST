﻿using System;
using System.Data.SqlClient;


namespace LIST.Areas.Leerling.Models
{
    public class LeerlingModel
    {
        

        string connectionstring = LIST.Classes.Engine.connectionstring();
        public Leerling getData(string token)
        {
            token = token.Remove(0, 1); //LET OP: Het eerste cijfer geeft het type van de gebruiker aan. Zo staat het niet in de database!!
            var model = new Leerling();
            try
            {
                SqlConnection connection = new SqlConnection(connectionstring);
                SqlCommand command = new SqlCommand("SELECT * FROM userdata WHERE token = @token", connection);
                command.Parameters.AddWithValue("@token", token);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    model.username = reader["username"].ToString();
                    model.naam = reader["firstname"].ToString();
                    model.achternaam = reader["surname"].ToString();
                    model.token = token;
                }
                connection.Close();
            }
            catch(Exception ex)
            {
                LIST.Classes.Engine.WriteError(ex.ToString(), "???");
            }
            return model;
             
        }
    }


}