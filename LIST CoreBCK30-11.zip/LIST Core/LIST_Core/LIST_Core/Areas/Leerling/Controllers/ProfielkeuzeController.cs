﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using LIST.Areas.Leerling.Models;

namespace LIST.Areas.Leerling.Controllers
{
    [Area("Leerling")]
    [Route("leerling/[controller]")]
    public class ProfielkeuzeController : Controller
    {
        // GET: LOB/Profiel
        [HttpGet]
        
        public ActionResult Index()
        {
            
            Profiel profiel = new ProfielModel().profielOphalen("");
            profiel.status = 0;
            
            return View("Profiel", profiel);
            
        }

        public ActionResult Keuzetest()
        {
            Response.Redirect("~/Forms/Profielkeuze.aspx");
            return null;
        }

        [HttpPost]
        public ActionResult UpdateProfiel(Profiel profiel)
        {
            if(ModelState.IsValid)
            {
                bool saved = new ProfielModel().UpdateKeuze(profiel, "");
                profiel = new ProfielModel().profielOphalen("");

                if (saved == true)
                {
                    profiel.status = 1;
                }
                else
                {
                    profiel.status = 2;
                }
            }
            return View("Profiel", profiel);
        }
    }
}