﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace LIST.Areas.Leerling.Controllers
{
    [Area("Leerling")]
    [Route("leerling/[controller]")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            string token = HttpContext.Session.GetString("Token");
            if(token != null)
            {
                LIST.Areas.Leerling.Models.LeerlingModel lmodel = new LIST.Areas.Leerling.Models.LeerlingModel();
                return View(lmodel.getData(token));
            }
            else
            {
                Response.Redirect("/Home");
                return Content("No token");
            }
        }
    }
}