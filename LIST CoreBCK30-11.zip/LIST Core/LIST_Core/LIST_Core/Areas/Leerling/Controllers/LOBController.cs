﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace LIST.Areas.Leerling.Controllers
{
    [Area("Leerling")]
    [Route("leerling/[controller]")]
    public class LOBController : Controller
    {
        // GET: LOB/Home
        public ActionResult Index()
        {
            return View();
        }
    }
}