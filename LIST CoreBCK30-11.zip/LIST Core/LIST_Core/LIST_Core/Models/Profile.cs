﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LIST.Models
{
    public class Profile
    {
        public int Id { get; set; }
        public int Studentcode { get; set; }
        public string Profilename { get; set; }
        public int Checked { get; set; }
    }

    public class Profiles
    {
        public int Id { get; set; }
        public string Profilename { get; set; }
        public string Active { get; set; }
        public string Vak1 { get; set; }
        public string Vak2 { get; set; }
        public string Vak3 { get; set; }
        public string Vak4 { get; set; }
        public string Vak5 { get; set; }
        public string Vak6 { get; set; }
        public string Vak7 { get; set; }
        public string Vak8 { get; set; }
        public string Vak9 { get; set; }
        public string Vak10 { get; set; }
        public string Vak11 { get; set; }
        public string Vak12 { get; set; }
        public string Vak13 { get; set; }
        public string Vak14 { get; set; }
        public string Vak15 { get; set; }
        public string Vak16 { get; set; }
        public string Vak17 { get; set; }
        public string Vak18 { get; set; }
        public string Vak19 { get; set; }
        public string Vak20 { get; set; }
        public string Vak21 { get; set; }
        public string Vak22 { get; set; }
        public string Vak23 { get; set; }
        public string Vak24 { get; set; }
    }

}
